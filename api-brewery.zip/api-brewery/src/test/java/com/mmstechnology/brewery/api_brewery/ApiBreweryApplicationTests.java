package com.mmstechnology.brewery.api_brewery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiBreweryApplicationTests {

	@Test
	void contextLoads() {
	}

}
