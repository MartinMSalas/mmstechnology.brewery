package com.mmstechnology.brewery.api_brewery;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiBreweryApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiBreweryApplication.class, args);
	}

}
